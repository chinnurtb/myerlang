/*jslint white: false, plusplus: false */
var MyLib = {};
MyLib.dude = function (warez) {
  return "my car";
};
