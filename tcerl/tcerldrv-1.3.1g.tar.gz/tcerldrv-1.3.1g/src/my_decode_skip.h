#ifndef _MY_DECODE_SKIP_H_
#define _MY_DECODE_SKIP_H_

#ifdef __cplusplus
extern "C"
    {
#endif

int 
my_ei_skip_term (const char* buf, int* index);

#ifdef __cplusplus
    }
#endif

#endif /* _MY_DECODE_SKIP_H_ */
