-module (gen_herd_test).

-export ([ start/3,
           get_values/1 ]).

-behaviour (gen_herd).
-export ([ init/1,
           handle_call/3,
           handle_cast/2,
           handle_info/2,
           terminate/2,
           code_change/3,
           create_task/2,
           init_task/2 ]).

-record (herdtest, { offset }).

%-=====================================================================-
%-                                Public                               -
%-=====================================================================-

start (NumParts, NumCopies, Offset) ->
  gen_herd:start (?MODULE, [ NumParts, NumCopies, Offset ], []).

get_values (Partition) ->
  gen_herd:multi_call (?MODULE, Partition, get_value).

%-=====================================================================-
%-                          gen_herd_callbacks                         -
%-=====================================================================-

init ([ NumParts, NumCopies, Offset ]) ->
  { ok, ?MODULE, NumParts, NumCopies, #herdtest{ offset = Offset } }.

handle_call (get_offset, _From, State) ->
  { reply, State#herdtest.offset, State }.

handle_cast (incr_offset, State) ->
  { noreply, State#herdtest{ offset = State#herdtest.offset + 1 } }.

handle_info (_Msg, State) ->
  { noreply, State }.

terminate (_Reason, _State) ->
  ok.

code_change (_OldVsn, State, _Extra) ->
  { ok, State }.

create_task (Partition, State) ->
  { ok, Pid } = gen_herd_test_task:start (Partition, State#herdtest.offset),
  Pid.

init_task (Pid, Group) ->
  gen_herd_test_task:finish_init (Pid, Group).
