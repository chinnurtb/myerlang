-module (testdb).
-behaviour (gen_fragment).
-export ([ init/1,
           handle_call/3,
           handle_cast/2,
           handle_info/2,
           terminate/2,
           code_change/3 ]).

-ifdef (MNESIA_EXT).
-ifdef (TCERL).
-define (USE_TCERL, 1).
-endif.
-endif.

-ifdef (USE_TCERL).
-define (target_type, n_external_copies).
-define (copy_type, { external, ordered_set, tcbdbtab }).
-else.
-define (target_type, n_ram_copies).
-define (copy_type, set).
-endif.

init ([ Table, Frags, Copies ]) ->
  gen_fragment:ensure_table (Table,
                             [ { type, ?copy_type },
                               { frag_properties, [
                                 { n_fragments, Frags },
                                 { node_pool, 
                                   mnesia:system_info (running_db_nodes) },
                                 { ?target_type, Copies }
                             ] } ]),

  { ok, [ Table ], void }.

handle_call (_Request, _From, void) -> { noreply, void }.
handle_cast (_Request, void) -> { noreply, void }.
handle_info (_Msg, void) -> { noreply, void }.
terminate (_Reason, void) -> ok.
code_change (_OldVsn, void, _Extra) -> { ok, void }.
