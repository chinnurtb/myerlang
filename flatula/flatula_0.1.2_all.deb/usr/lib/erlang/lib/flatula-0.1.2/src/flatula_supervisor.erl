-module (flatula_supervisor).

-export ([ start_link/0 ]).

-behaviour (supervisor).
-export ([ init/1 ]).

-define (MAX_RESTARTS, 3).
-define (MAX_RESTART_INTERVAL, 10).
-define (SERVER_STOP_TIMEOUT, 30000).

start_link () ->
  supervisor:start_link ({ local, ?MODULE }, ?MODULE, []).

init ([]) ->
  Strategy = { one_for_one, ?MAX_RESTARTS, ?MAX_RESTART_INTERVAL },
  ChildSpecs = [ { flatula_server,
		   { flatula_server, start_link, [] },
		   permanent,
		   ?SERVER_STOP_TIMEOUT,
		   worker,
		   [ flatula_server ] },
		 { flatula_table_supervisor,
		   { flatula_table_supervisor, start_link, [] },
		   permanent,
		   infinity,
		   supervisor,
		   [ flatula_table_supervisor ] } ],
  { ok, { Strategy, ChildSpecs } }.
