% simple_one_for_one supervisor to manage flatula_table instances.

-module (flatula_table_supervisor).

-export ([ start_link/0 ]).

-behaviour (supervisor).
-export ([ init/1 ]).

-define (STOP_TIMEOUT, 30000).

start_link () ->
  supervisor:start_link ({ local, ?MODULE }, ?MODULE, []).

init ([]) ->
  % temporary children are never restarted
  Strategy = { simple_one_for_one, 0, 1 },
  ChildSpecs = [ { flatula_table,
		   { flatula_table, start_link, [] },
		   temporary,
		   ?STOP_TIMEOUT,
		   worker,
		   [ flatula_table ] } ],
  { ok, { Strategy, ChildSpecs } }.
