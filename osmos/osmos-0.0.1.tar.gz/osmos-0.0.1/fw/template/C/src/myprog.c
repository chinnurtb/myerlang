int main (void);

int main (void) 
  {
    return 0;
  }
