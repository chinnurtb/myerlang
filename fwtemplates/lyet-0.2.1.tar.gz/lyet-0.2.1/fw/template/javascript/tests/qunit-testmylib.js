$(document).ready (function () { 
  test ("mytestcase", function () { 
     expect (1);
     equals (MyLib.dude (0), "my car");
  });
});
